from brain_games.games import brain_gcd_logic


def main():
    brain_gcd_logic.brain_gcd()


if __name__ == '__main__':
    main()
