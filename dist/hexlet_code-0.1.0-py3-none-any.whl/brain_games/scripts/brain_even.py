from brain_games.games import brain_even_logic


def main():
    brain_even_logic.brain_even()

if __name__ == '__main__':
    main()
