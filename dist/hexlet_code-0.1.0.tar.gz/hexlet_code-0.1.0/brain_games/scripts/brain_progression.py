from brain_games.games import brain_progression_logic


def main():
    brain_progression_logic.brain_progression()


if __name__ == "__main__":
    main()
