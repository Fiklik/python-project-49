from brain_games.games import brain_calc_logic


def main():
    brain_calc_logic.brain_calc()


if __name__ == '__main__':
    main()
