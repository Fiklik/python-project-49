from brain_games.games import brain_prime_logic


def main():
    brain_prime_logic.brain_prime()


if __name__ == '__main__':
    main()
